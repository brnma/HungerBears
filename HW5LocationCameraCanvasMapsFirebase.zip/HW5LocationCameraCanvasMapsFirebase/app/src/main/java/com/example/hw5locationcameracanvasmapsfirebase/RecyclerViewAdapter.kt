package com.example.hw5locationcameracanvasmapsfirebase

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.collections.ArrayList


class RecyclerViewAdapter(private val locationList: ArrayList<locationItem>):
    RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.card_view, parent, false)

        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {


        val currentItem = locationList[position]

        holder.latlong.text = "${currentItem.latitude} ${currentItem.longitude}"
        holder.timestamp.text = currentItem.time
        holder.address.text = currentItem.address

        holder.itemView.setOnClickListener {
            val uri: String = java.lang.String.format(
                Locale.ENGLISH,
                "geo:%s,%s",
                currentItem.latitude,
                currentItem.longitude
            )
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return locationList.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

        val latlong: TextView = itemView.findViewById(R.id.latlong)
        val address: TextView = itemView.findViewById(R.id.address)
        val timestamp: TextView = itemView.findViewById(R.id.timestamp)
    }
}