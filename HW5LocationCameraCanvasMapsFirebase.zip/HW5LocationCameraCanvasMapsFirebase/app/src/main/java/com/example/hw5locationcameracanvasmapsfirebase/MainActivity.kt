package com.example.hw5locationcameracanvasmapsfirebase

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hw5locationcameracanvasmapsfirebase.databinding.ActivityMainBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.*
import kotlinx.coroutines.Job
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*

class MainActivity : AppCompatActivity() {
    // an instance of MyCanvas
    lateinit var myCanvas: MyCanvas

    // database stuff
    private lateinit var dbref: DatabaseReference
    private lateinit var locationRecyclerView: RecyclerView
    private lateinit var locationList : ArrayList<locationItem>

    //Setup some variables
    //A Job for async access to the geocoding lookup
    private var coroutineJob: Job? = null

    //A connection to the Google Play location API
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    //Geocoder will handling the address lookup
    lateinit var  geocoder : Geocoder

    var addresses: List<Address> = emptyList()

    private lateinit var binding: ActivityMainBinding
    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        locationList = arrayListOf<locationItem>()
        getLocationData()

        //Geocoder will handling the address lookup
        geocoder = Geocoder(this, Locale.getDefault())
        setContentView(R.layout.activity_main)

        //Create a location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)


        dbref = FirebaseDatabase.getInstance().getReference("Locations")

        val button: FloatingActionButton = findViewById(R.id.floatingActionButton)
        button.setOnClickListener() {
            var lat = ""
            var lng = ""
            var address = ""
            var timestamp = ""

            val test = locationItem("latitude1", "longitude2", "address3", "time4")

            //get the last location identified. Also, set a listener that updates the
            //R.id.coordinates text when the location is found (on Success)
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location : Location? ->
                    // Got the last known location. In some rare situations this can be null.

                    val currentTime = LocalDateTime.now()
                    val formatter: DateTimeFormatter =
                        DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss")

                    val timestamp = formatter.format(currentTime)

                    val currItem = locationItem(location?.latitude.toString(), location?.longitude.toString(),
                        location?.let { it1 -> getAddress(it1) }, timestamp)

                    dbref.child(location?.time.toString()).setValue(currItem).addOnSuccessListener {
                        Toast.makeText(this, "Success", Toast.LENGTH_SHORT).show()
                    }
                        .addOnFailureListener{
                            Toast.makeText(this, "Fao;", Toast.LENGTH_SHORT).show()
                        }

                    getLocationData()
                    locationRecyclerView.adapter?.notifyDataSetChanged()
                }

            //This will let the user know when the location was not able to be found.
            fusedLocationClient.lastLocation
                .addOnFailureListener {
                Toast.makeText(this, "Failed to get location", Toast.LENGTH_SHORT).show()
                }
        }

        locationRecyclerView = findViewById(R.id.recyclerView)
        locationRecyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun getLocationData() {
        dbref = FirebaseDatabase.getInstance().getReference("Locations")

        dbref.addValueEventListener(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()){
                    locationList.clear()
                    for (locationSnapshot in snapshot.children){


                        val location = locationSnapshot.getValue(locationItem::class.java)
                        locationList.add(location!!)
                    }

                    locationRecyclerView.adapter = RecyclerViewAdapter(locationList)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }


    private fun getAddress(location: Location): String {

        //adapted from https://developer.android.com/training/location/display-address.html
        //the geocoder can convert a lat/long location to an address
        //We get the location from the fusedLocationClient instance
        try {
            addresses = geocoder.getFromLocation(
                location.latitude,
                location.longitude,
                // In this sample, we get just a single address.
                1)
        } catch (ioException: IOException) {
            // Catch network or other I/O problems.
            return "Error: Service Not Available --$ioException"

        } catch (illegalArgumentException: IllegalArgumentException) {
            // Catch invalid latitude or longitude values.
            return "Error: Invalid lat long used--$illegalArgumentException"
        }

        if(addresses.isEmpty())
            return "No address found :("

        return "Address: "+addresses.get(0).getAddressLine(0)+"\n"+"City:"+addresses.get(0).getLocality()+"\n"+"Zip code:"+addresses.get(0).getPostalCode()

    }

    //touchandler-> this function relays it to -> myCanvas
    //You can also allow touchHandler to update myCanvas directly
    // (this will require passing myCanvas to touchHandler).
    fun addNewPath(id: Int, x: Float, y: Float) {
        myCanvas.addPath(id, x, y)
    }

    fun updatePath(id: Int, x: Float, y: Float) {
        myCanvas.updatePath(id, x, y)
    }

    fun removePath(id: Int) {
        myCanvas.removePath(id)
    }

    /**
     * This function is called by TouchHandler when a doubleTap is detected.
     * It changes the background color of the canvas.
     */
    fun onDoubleTap() {
        //double tapping changes the background to a random color
        myCanvas.setBackgroundColor(
            Color.rgb(
                (0..255).random(), (0..255).random(),
                (0..255).random()
            )
        )
    }

    /**
     * This function is called by TouchHandler when a longPress is detected.
     * It activates the camera Intent
     */
    fun onLongPress() {
        //takes a picture and chnages the background to it
        dispatchTakePictureIntent()
    }

    /**
     * adapted from https://developer.android.com/training/camera/photobasics/
     */

    lateinit var currentPhotoPath: String

    @Throws(IOException::class)
    /**
     * This function creates a file to store the image taken by the camera.
     */
    private fun createImageFile(): File {
        // Create an image file name. Adding the date and time to the file name
        // ensures that the file name is unique.
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        // Get a handle to the file in the file system
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)

        // Create a file to store the image with the name "JPEG_<date>_<time>.jpg"
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file path for use with ACTION_VIEW intents
            currentPhotoPath = absolutePath
        }
    }


    /**
     * adapted from https://developer.android.com/training/camera/photobasics/
     */
    val REQUEST_TAKE_PHOTO = 1

    lateinit var photoURI: Uri
    private fun dispatchTakePictureIntent() {
        // Create an implicit intent to take a picture and return control to the calling application
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            // Ensure that there's a camera activity to handle the intent
            takePictureIntent.resolveActivity(packageManager)?.also {
                // Create the File where the photo should go
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    Log.e("Picture Intent", "Error creating file")
                    null
                }
                // Continue only if the File was successfully created
                photoFile?.also {
                    photoURI = FileProvider.getUriForFile(
                        this,
                        "com.example.hw5locationcameracanvasmapsfirebase",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO)
                }
            }
        }
    }

    /**
     * adapted from https://developer.android.com/training/camera/photobasics/
     */
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode === REQUEST_TAKE_PHOTO && resultCode === Activity.RESULT_OK) {
            this.contentResolver.notifyChange(photoURI, null)
            val cr = this.contentResolver
            Log.d("test", "result ok")
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(cr, photoURI)
                myCanvas.background = BitmapDrawable(resources, bitmap)
            } catch (e: IOException) {
                Log.d("test", "activity result error")
                e.printStackTrace()
            }

        }
    }

}