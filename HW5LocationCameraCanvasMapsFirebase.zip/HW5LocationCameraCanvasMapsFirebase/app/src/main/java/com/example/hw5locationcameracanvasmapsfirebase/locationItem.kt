package com.example.hw5locationcameracanvasmapsfirebase

data class locationItem(var latitude: String? = "",
                        var longitude: String? = "",
                        var address: String? = "",
                        var time: String? = "")